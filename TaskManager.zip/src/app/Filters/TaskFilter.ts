import { Pipe, PipeTransform } from '@angular/core';
import { TaskModelModule } from '../Model/task-model.module';
import { IMPLICIT_REFERENCE } from '@angular/compiler/src/render3/view/util';

@Pipe({
name: 'taskFilter'
})

export class TaskFilterPipe implements PipeTransform
{
    transform(items : TaskModelModule[], filter : TaskModelModule) : any {
        if(!items || !filter)
        {
            return items;
        }
        return items.filter(item =>
            item.TaskDescripton.indexOf(filter.TaskDescripton) != -1 &&
            item.ParentTask.ParentTaskName.indexOf(filter.ParentTask.ParentTaskName) != -1 &&
            item.Priority >= filter.Priority &&
            item.Priority <= filter.PriorityTo
            //item.StartDate.indexOf(filter.TaskDescripton) != -1 &&
            //item.TaskDescripton.indexOf(filter.TaskDescripton) != -1
        )
    }
}